#!/bin/bash
set -euo pipefail
umask 022

mode=${1:?check or build}
size_gib=${2:?virtual disk size}
channel=${3:-edge}
[[ $mode == check || $mode == build ]]
# Omarchy comes from the selected channel's signed repository at build time.
# The reviewed-entry check below fails closed on any release whose install
# scripts or owner programs the manager has not reviewed.
case $channel in
  stable) runtime_package=omarchy settings_package=omarchy-settings ;;
  edge) runtime_package=omarchy-dev settings_package=omarchy-settings-dev ;;
  *) printf 'Unknown Omarchy channel: %s\n' "$channel" >&2; exit 1 ;;
esac
[[ $(uname -m) == aarch64 ]]
[[ -d /input-profile && -d /workspace/guest && -d /downloads && -d /output ]]
available=$(df --output=avail -B1 /work | tail -1 | tr -d ' ')
((available >= 3 * 1024 * 1024 * 1024)) || {
  printf 'Docker needs at least 3 GiB free for source/package work; no other data is pruned.\n' >&2
  exit 1
}

cp -a /input-profile /profile
lock=/profile/inputs.lock.json
field() { jq -er ".$1" "$lock"; }

mkdir -p /work/package-build /output/packages /work/omarchy-packages /work/omarchy-root

pacman-key --populate omarchy
sed -i "/^\[core\]/i [omarchy]\nServer = https://pkgs.omarchy.org/$channel/\$arch\n" /etc/pacman.conf
pacman -Syu --needed --noconfirm imagemagick
mkdir -p /output/repositories
cp /var/lib/pacman/sync/*.db /output/repositories/

# Download (and signature-check) exactly the channel's Omarchy pair, without
# dependencies. These archives are what the image installs.
pacman -Swdd --noconfirm --cachedir /work/omarchy-packages "$settings_package" "$runtime_package"
for name in "$settings_package" "$runtime_package"; do
  matches=(/work/omarchy-packages/"$name"-[0-9]*.pkg.tar.zst)
  ((${#matches[@]} == 1)) || { printf 'Expected one %s package\n' "$name" >&2; exit 1; }
  install -m 0644 "${matches[0]}" /output/packages/
  bsdtar -xf "${matches[0]}" -C /work/omarchy-root
done
python3 /profile/compatibility.py patch-source --installed /work/omarchy-root /profile /profile/source-compatibility.json
cp /profile/source-compatibility.json /output/source-compatibility.json

useradd --create-home builder
chown -R builder:builder /work/package-build

build_package() {
  local name=$1 recipe=$2
  cp -a "$recipe" "/work/package-build/$name"
  chown -R builder:builder "/work/package-build/$name"
  (
    cd "/work/package-build/$name"
    runuser -u builder -- env PKGEXT=.pkg.tar.zst \
      makepkg --nodeps --force --noconfirm
    local packages=(./*.pkg.tar.zst)
    ((${#packages[@]} == 1))
    install -m 0644 "${packages[0]}" /output/packages/
  )
}

# Repacking changes the complete archive identity even when payloads are identical.
# Verify the transformed source again inside the container, then install the exact
# reviewed archive through the same resolver and pacstrap path as other packages.
python3 - <<'PY'
import json, sys
from pathlib import Path
sys.path.insert(0, '/profile')
from compatibility import digest, integration_recipe_digest
lock = json.loads(Path('/profile/inputs.lock.json').read_text())
reviewed = lock['reviewed_integration']
archive = Path('/profile') / reviewed['archive']
assert not archive.is_symlink() and digest(archive) == reviewed['sha256'], 'Reviewed archive checksum mismatch'
assert reviewed['sha256'] == json.loads(Path('/profile/guest-integration-compatibility.json').read_text())['leanPackageSHA256']
assert integration_recipe_digest(Path('/workspace/guest/package/try-omarchy')) == reviewed['recipe_sha256'], 'Integration recipe changed; manager policy review required'
PY
install -m 0644 "/profile/$(field reviewed_integration.archive)" /output/packages/
build_package dev-workstation-preferences /profile/preferences

python3 /profile/check-provisioning.py /work/omarchy-root/usr/share/omarchy /output/provisioning-check.json

for package in /output/packages/*.pkg.tar.zst; do
  bsdtar -xOf "$package" .PKGINFO
done >/output/local-package-metadata.txt
mkdir -p /work/local-repository /work/resolution/var/lib/pacman
cp /output/packages/*.pkg.tar.zst /work/local-repository/
repo-add /work/local-repository/dev-workstation-image.db.tar.gz /work/local-repository/*.pkg.tar.zst
sed -i '/^\[omarchy\]/i [dev-workstation-image]\nServer = file:///work/local-repository\n' /etc/pacman.conf
pacman --root /work/resolution --dbpath /work/resolution/var/lib/pacman \
  --gpgdir /etc/pacman.d/gnupg -Sy --noconfirm
python3 - <<'PY'
import json, re, subprocess, sys
from pathlib import Path
sys.path.insert(0, '/profile')
from compatibility import check_package_set, package_list

metadata = Path('/output/local-package-metadata.txt').read_text().splitlines()
local = set()
targets = set(package_list('/profile/base.packages'))
for line in metadata:
    key, _, value = line.partition(' = ')
    if key == 'pkgname':
        local.add(value)
    if key == 'optdepend':
        targets.add(value.split(': ', 1)[0])
targets.update(local)
try:
    result = subprocess.run(['pacman', '--root', '/work/resolution', '--dbpath',
                            '/work/resolution/var/lib/pacman', '--gpgdir', '/etc/pacman.d/gnupg',
                            '-Sp', '--print-format', '%n %v', *sorted(targets)],
                            check=True, capture_output=True, text=True)
except subprocess.CalledProcessError as error:
    raise SystemExit('Dependency resolution failed: ' + error.stderr.strip())
Path('/output/resolved-repository-packages.txt').write_text(result.stdout)
installed = {line.split()[0] for line in result.stdout.splitlines()}
check_package_set(installed, package_list('/profile/base.packages') + sorted(local),
                  package_list('/profile/excluded.packages'))
Path('/output/package-resolution.json').write_text(json.dumps({
    'format': 1, 'package_resolution': 'passed', 'local_packages': sorted(local),
    'resolved_packages': len(installed), 'owner_first_boot': 'not-tested',
    'hardware_rendering': 'not-tested', 'manager_admitted': False,
}, indent=2) + '\n')
PY

if [[ $mode == check ]]; then
  printf 'Compatibility package build, source checks and dependency resolution passed.\n'
  exit 0
fi

mkdir -p /packages
cp /output/packages/*.pkg.tar.zst /packages/
integration=(/packages/try-omarchy-*.pkg.tar.zst)
preferences=(/packages/dev-workstation-preferences-*.pkg.tar.zst)
((${#integration[@]} == 1 && ${#preferences[@]} == 1))
bash /workspace/guest/factory/build-image.sh \
  --output /output --work /factory-work --size-gib "$size_gib" --channel "$channel" \
  --package "${integration[0]}" --package "${preferences[0]}"
