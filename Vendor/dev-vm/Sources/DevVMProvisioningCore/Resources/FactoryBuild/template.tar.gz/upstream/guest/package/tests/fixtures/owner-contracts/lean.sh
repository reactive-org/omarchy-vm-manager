keyboard_xkb_settings() {
  local layout variant="" options=terminate:ctrl_alt_bksp
  local switch=terminate:ctrl_alt_bksp,grp:shifts_toggle,grp_led:scroll

  case $1 in
    colemak) layout=us variant=colemak ;;
    bg-cp1251) layout=bg,us variant=phonetic, options=$switch ;;
    cz) layout=cz,us variant=qwerty, options=$switch ;;
    de_CH-latin1) layout=ch ;;
    kyrgyz) layout=kg,us options=$switch ;;
    no-latin1) layout=no ;;
    pl) layout=pl ;;
    ua) layout=ua,us options=$switch ;;
    *) return 1 ;;
  esac

  printf 'XKBLAYOUT=%s\nXKBMODEL=pc105\n' "$layout"
  [[ -z $variant ]] || printf 'XKBVARIANT=%s\n' "$variant"
  printf 'XKBOPTIONS=%s\n' "$options"
}

apply_keyboard() {
  local keymap=$1 keymaps saved

  if [[ $(tty 2>/dev/null) == /dev/tty* ]] && ! loadkeys "$keymap" >>"$LOG_FILE" 2>&1; then
    log_step "loadkeys could not load keymap $keymap"
    return 1
  fi

  if ! keymaps=$(localectl --no-pager list-keymaps 2>>"$LOG_FILE"); then
    log_step "localectl could not list keymaps to check $keymap"
    return 1
  fi
  if ! grep -qxF -- "$keymap" <<<"$keymaps"; then
    log_step "keymap $keymap unknown to localectl"
    return 1
  fi

  if ! systemd-firstboot --keymap="$keymap" --force >>"$LOG_FILE" 2>&1 &&
    ! localectl set-keymap "$keymap" >>"$LOG_FILE" 2>&1; then
    log_step "could not persist keymap $keymap"
    return 1
  fi

  # systemd-firstboot writes an XKB layout only for keymaps in kbd-model-map,
  # and several the form offers are not, so Hyprland would come up in US.
  if ! grep -q '^XKBLAYOUT=.' /etc/vconsole.conf 2>/dev/null; then
    keyboard_xkb_settings "$keymap" >>/etc/vconsole.conf 2>>"$LOG_FILE" ||
      log_step "no XKB layout known for keymap $keymap"
  fi

  # A clean shell, so nothing this process exported stands in for the file.
  saved=$(env -i /bin/bash --noprofile --norc -c \
    '. /etc/vconsole.conf && [[ -n ${XKBLAYOUT:-} ]] && printf %s "${KEYMAP:-}"' 2>>"$LOG_FILE") || saved=""
  if [[ $saved != "$keymap" ]]; then
    log_step "/etc/vconsole.conf does not read back as keymap $keymap with an XKB layout"
    return 1
  fi
}

cleanup_oem_state() {
  rm -f "$PROVISIONING_DIR/pending" "$PROVISIONING_DIR/authorized_keys" "$PROVISIONING_DIR/setup-user" "$REKEY_STATE"

  rm -f /etc/systemd/system/multi-user.target.wants/omarchy-provision-owner.service
  systemctl daemon-reload 2>/dev/null || true
}

run_provisioning() {
  log_step "creating user $username"
  create_user
  install_authorized_keys
  configure_login

  log_step "setting hostname to ${hostname:-omarchy}"
  configure_hostname

  log_step "setting timezone to ${timezone:-UTC}"
  configure_timezone

  log_step "finalizing user"
  echo finalize >"$STATE_FILE"
  if ! finalize_user; then
    log_step "finalize-user failed (continuing)"
    touch "$FINALIZE_WARNING_FLAG"
  fi

  if luks_rekey_pending; then
    log_step "re-keying LUKS to the user's password"
    echo rekey >"$STATE_FILE"
    rekey_luks
    log_step "LUKS re-key complete"
  fi

  # On an unencrypted machine nothing above rebuilds the boot entries. The
  # factory reset already keyed them to this identity, so this only repairs a
  # machine left without an entry of its own.
  if limine_entries_stale; then
    log_step "refreshing boot entries for the new machine identity"
    echo boot >"$STATE_FILE"
    reset_limine_config
    limine-update
  fi

  if luks_staged_unlock_remains; then
    log_step "refusing to finish setup while the staged LUKS key or its auto-unlock remains"
    return 1
  fi

  log_step "cleaning up provisioning state"
  cleanup_oem_state
  log_step "first-boot setup complete"
}

finalize_user() {
  local home shell
  home=$(getent passwd "$username" | cut -d: -f6)
  shell=$(getent passwd "$username" | cut -d: -f7)

  runuser -u "$username" -- env \
    HOME="$home" \
    USER="$username" \
    LOGNAME="$username" \
    SHELL="${shell:-/bin/bash}" \
    OMARCHY_PATH="$OMARCHY_PATH" \
    OMARCHY_INSTALL="$OMARCHY_PATH/install" \
    OMARCHY_SETUP_CONTEXT=provision-owner \
    OMARCHY_INSTALL_LOG_FILE="$LOG_FILE" \
    OMARCHY_LOG_TO_STDOUT=1 \
    "$OMARCHY_PATH/bin/omarchy-provision-user" --force --first-install
}
