#!/usr/bin/env python3
import hashlib
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock
import uuid

SOURCE = Path(__file__).resolve().parents[1] / "try-omarchy/files/usr/lib/try-omarchy/managed-ssh"


class ManagedSSH(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="managed-ssh-test-")
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        loader = importlib.machinery.SourceFileLoader("managed_ssh_test", str(SOURCE))
        spec = importlib.util.spec_from_loader(loader.name, loader)
        self.module = importlib.util.module_from_spec(spec)
        loader.exec_module(self.module)
        m = self.module
        m.BASE = root / "state"; m.RUN = root / "run"; m.SHARE = root / "share"
        m.CMDLINE = root / "cmdline"; m.PENDING = root / "pending"; m.ROOT = root / "system"
        m.SYSTEMCTL = "/test-systemctl"
        m.SHARE.mkdir(mode=0o700)
        m.CMDLINE.write_text("tryomarchy.ssh_access=1 tryomarchy.managed_ssh=1\n")
        self.manifest = {"schemaVersion": 1, "vmID": str(uuid.uuid4()), "sessionToken": str(uuid.uuid4()), "publicKeys": []}
        subprocess.run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "fixture", "-f", str(m.SHARE / "host_ed25519")], check=True)
        key = m.public_key((m.SHARE / "host_ed25519.pub").read_text().strip())
        self.manifest["publicKeys"] = [key]
        self.write_manifest()
        self.commands = []
        run = subprocess.run
        self.actual_run = run
        def execute(args, **kwargs):
            if args[0] == "/usr/bin/ssh-keygen":
                return run(args, **kwargs)
            self.commands.append(args)
            return subprocess.CompletedProcess(args, 0, stdout=b"", stderr=b"")
        self.addCleanup(mock.patch.stopall)
        mock.patch.object(m.subprocess, "run", side_effect=execute).start()
        mock.patch.dict(os.environ, {"TRY_OMARCHY_MANAGED_SHARE": str(m.SHARE)}).start()
        mock.patch.object(m.pwd, "getpwall", return_value=[SimpleNamespace(pw_name="owner", pw_uid=1000, pw_shell="/bin/bash")]).start()

    def write_manifest(self):
        (self.module.SHARE / "manifest.json").write_text(json.dumps(self.manifest))

    def test_official_and_lean_finalization_warning_blocks_ssh_until_successful_retry(self):
        from test_managed_setup import ManagedSetupTests
        m = self.module
        root = m.PENDING.parent
        runner = ManagedSetupTests()
        for kind in ('official', 'lean'):
            m.PENDING.touch(); (root / 'log').touch()
            with mock.patch.object(m.subprocess, 'run', side_effect=self.actual_run):
                self.assertNotEqual(runner.run_bash(root, kind, 'warning').returncode, 0)
            m.main()
            self.assertEqual(json.loads((m.RUN / 'status.json').read_bytes())['state'], 'waiting-owner')
            with mock.patch.object(m.subprocess, 'run', side_effect=self.actual_run):
                self.assertEqual(runner.run_bash(root, kind).returncode, 0)
            m.main()
            self.assertEqual(json.loads((m.RUN / 'status.json').read_bytes())['state'], 'configured')

    def test_managed_setup_requires_current_configured_owner_report(self):
        m=self.module
        m.CMDLINE.write_text(m.CMDLINE.read_text()+' tryomarchy.managed_setup=1')
        path=m.ROOT/'run/try-omarchy/managed-setup/status.json'
        path.parent.mkdir(parents=True,mode=0o700)
        for state,token,ready in [('error',self.manifest['sessionToken'],False),('configured',str(uuid.uuid4()),False),('configured',self.manifest['sessionToken'],True)]:
            path.write_text(json.dumps(dict(schemaVersion=1,vmID=self.manifest['vmID'],sessionToken=token,state=state,owner='owner')))
            m.main()
            self.assertEqual(json.loads((m.RUN/'status.json').read_bytes())['state'],'configured' if ready else 'waiting-owner')
        path.chmod(0o666)
        with self.assertRaises(ValueError):m.main()

    def test_waits_for_normal_owner_setup_without_starting_ssh(self):
        m = self.module
        m.PENDING.touch()
        m.main()
        status = json.loads((m.RUN / "status.json").read_text())
        self.assertEqual(status["state"], "waiting-owner")
        self.assertFalse(any("sshd.service" in x for x in self.commands))

    def test_enrolls_only_managed_key_files_and_uses_vendor_service(self):
        m = self.module
        m.main()
        keys = (m.BASE / "authorized/owner").read_text()
        self.assertEqual(keys.strip(), self.manifest["publicKeys"][0])
        config = (m.RUN / "sshd_config").read_text()
        self.assertIn("AuthorizedKeysFile .ssh/authorized_keys ", config)
        self.assertIn("PermitRootLogin no", config)
        self.assertIn("PasswordAuthentication no", config)
        self.assertIn("AllowUsers owner", config)
        self.assertTrue(any(x[1:] == ["restart", "sshd.service"] for x in self.commands))
        self.assertEqual(json.loads((m.RUN / "status.json").read_text())["owner"], "owner")
        self.assertEqual((m.BASE / "host_ed25519").stat().st_mode & 0o777, 0o600)
        self.assertEqual(m.RUN.stat().st_mode & 0o777, 0o755)

    def test_restart_preserves_host_identity_and_updates_only_session_status(self):
        m = self.module; m.main()
        before = hashlib.sha256((m.BASE / "host_ed25519").read_bytes()).hexdigest()
        self.manifest["sessionToken"] = str(uuid.uuid4()); self.write_manifest(); m.main()
        self.assertEqual(hashlib.sha256((m.BASE / "host_ed25519").read_bytes()).hexdigest(), before)
        self.assertEqual(json.loads((m.RUN / "status.json").read_text())["sessionToken"], self.manifest["sessionToken"])

    def test_vm_identity_changes_are_refused_without_overwriting_keys(self):
        m = self.module; m.main()
        before = hashlib.sha256((m.BASE / "host_ed25519").read_bytes()).hexdigest()
        self.manifest["vmID"] = str(uuid.uuid4()); self.write_manifest()
        with self.assertRaises(ValueError): m.main()
        self.assertEqual(hashlib.sha256((m.BASE / "host_ed25519").read_bytes()).hexdigest(), before)

    def test_newer_schema_options_and_private_material_are_refused(self):
        m = self.module
        for key in ("command=bad ssh-ed25519 AAAA", "-----BEGIN OPENSSH PRIVATE KEY-----", "ssh-ed25519 !bad"):
            with self.assertRaises(ValueError): m.public_key(key)
        self.manifest["schemaVersion"] = 2; self.write_manifest()
        with self.assertRaises(ValueError): m.main()
        self.assertFalse((m.BASE / "host_ed25519").exists())

    def test_timer_cannot_form_a_cycle_through_basic_target(self):
        import configparser
        units = SOURCE.parents[1] / "systemd/system"
        timer = configparser.ConfigParser(interpolation=None, strict=False)
        timer.read(units / "try-omarchy-managed-ssh.timer")
        for dependency in timer["Unit"].get("After", "").split():
            if not dependency.endswith(".service"):
                continue
            service = configparser.ConfigParser(interpolation=None, strict=False)
            service.read(units / dependency)
            self.assertEqual(service["Unit"].get("DefaultDependencies", "yes"), "no", "Timer → default service → basic.target → timers.target is a boot cycle")
        service = configparser.ConfigParser(interpolation=None, strict=False)
        service.read(units / "try-omarchy-managed-ssh.service")
        self.assertIn("try-omarchy-package-install.service", service["Unit"]["After"].split())

    def test_failure_reports_only_bounded_stage_and_codes(self):
        m = self.module
        with mock.patch.object(m, "owner_account", side_effect=OSError(13, "secret-must-not-leak")):
            self.assertEqual(m.run(), 1)
        text = (m.RUN / "status.json").read_text()
        self.assertNotIn("secret-must-not-leak", text)
        report = json.loads(text)
        self.assertEqual(report["failureStage"], "owner")
        self.assertEqual(report["failureCode"], "file-access")
        self.assertEqual(report["failureStatus"], 13)
        self.assertEqual(report["state"], "error")

    def test_repeated_enrollment_accepts_only_the_expected_readonly_mount(self):
        m = self.module
        m.MOUNTINFO = m.SHARE.parent / "mountinfo"
        m.MOUNTINFO.write_text(f"31 1 0:1 / {m.SHARE} ro,relatime - 9p tryomarchy-managed-ssh rw\n")
        original = m.private_directory
        def guest_directory(path, mode=0o700):
            if path == m.SHARE:
                raise m.ProvisioningError("unsafe-directory")
            original(path, mode)
        with mock.patch.object(m, "private_directory", side_effect=guest_directory), mock.patch.object(m.os.path, "ismount", return_value=True), mock.patch.dict(os.environ, {}, clear=True):
            m.main()
            m.main()
        self.assertEqual(json.loads((m.RUN / "status.json").read_text())["state"], "configured")
        for options, filesystem, source in [("rw", "9p", "tryomarchy-managed-ssh"), ("ro", "ext4", "tryomarchy-managed-ssh"), ("ro", "9p", "other-share")]:
            m.MOUNTINFO.write_text(f"31 1 0:1 / {m.SHARE} {options} - {filesystem} {source} rw\n")
            with mock.patch.object(m.os.path, "ismount", return_value=True), self.assertRaises(m.ProvisioningError):
                m.mount_share()

    def test_no_managed_token_is_a_noop(self):
        m = self.module; m.CMDLINE.write_text("tryomarchy.ssh_access=1\n"); m.main()
        self.assertFalse(m.BASE.exists())
        self.assertFalse(self.commands)


if __name__ == "__main__": unittest.main()
